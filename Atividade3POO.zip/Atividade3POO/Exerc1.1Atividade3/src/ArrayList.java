public class ArrayList{
    double numTotal = 30000;
    int arrayList[];
    int i;
    void Array(){
        for (int i=0; i<numTotal; i++){
            int num = arrayList[i];
        }
    }
}
